<!--A Design by W3layouts
   Author: W3layout
   Author URL: http://w3layouts.com
   License: Creative Commons Attribution 3.0 Unported
   License URL: http://creativecommons.org/licenses/by/3.0/
   -->
<!DOCTYPE html>
<html lang="zxx">

<head>
  <title>MID DAY MEALS</title>
  <!--meta tags -->
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="keywords" content="Organic Store Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
         Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design"
  />
  <script>
    addEventListener("load", function () {
      setTimeout(hideURLbar, 0);
    }, false);


    function hideURLbar() {
      window.scrollTo(0, 1);
    }
  </script>
  <!--booststrap-->
  <link href="../midday_meals/css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
  <!--//booststrap end-->
  <!-- font-awesome icons -->
  <link href="../midday_meals/css/font-awesome.min.css" rel="stylesheet">
  <!-- //font-awesome icons -->
  <!--stylesheets-->
  <link href="../midday_meals/css/style.css" rel='stylesheet' type='text/css' media="all">
  <!--//stylesheets-->
  <link href="//fonts.googleapis.com/css?family=Raleway:400,500,600,700" rel="stylesheet">
  <link href="//fonts.googleapis.com/css?family=Patrick+Hand" rel="stylesheet">
  <link href="//fonts.googleapis.com/css?family=Roboto:400,500,700" rel="stylesheet">
</head>

<body>
  <!-- //banner -->
  <div class="banner-left-side" id="home">
    <!-- header -->
    <div class="headder-top">
      <!-- nav -->
      <nav>
        <div id="logo">
          <h1>
            <a href="../midday_meals/index.html">MM</a>
          </h1>
        </div>
        <div class="sub-headder position-relative">
          <h6>
            <a href="../midday_meals/index.html">MID DAY
              <br>MEALS</a>
          </h6>
    </div>
        <label for="drop" class="toggle">Menu</label>
        <input type="checkbox" id="drop">
        <ul class="menu mt-2">
          <li class="active">
            <a href="../midday_meals/index.php">Home</a>          </li>
          <li>
            <a href="#about">About</a>          </li>
          <li>
            <a href="#service">Services</a>          </li>
          <li>
            <!-- First Tier Drop Down -->
            <!--<label for="drop-2" class="toggle toogle-2">Dropdown <span class="fa fa-angle-down" aria-hidden="true"></span>
              </label>
              <a href="#">Dropdown <span class="fa fa-angle-down" aria-hidden="true"></span></a>
              <input type="checkbox" id="drop-2">
              <ul>
                <li><a href="gallery.html" class="drop-text">Gallery</a></li>
                <li><a href="menu.html" class="drop-text">Menu</a></li>
                <li><a href="recipe.html" class="drop-text">Recipes</a></li>
              </ul>
            </li>-->
          <li>
              <a href="#gallery">Gallery</a>            </li>
            <li>
                          </li>
            <li>
              <a href="../login.php"> Login</a>            </li>
        </ul>
      </nav>
      <!-- //nav -->
</div>
    <!-- //header -->
    <!-- banner -->
    <div class="main-banner text-center">
      <div class="container">
        <div class="social-icons mb-lg-4 mb-3">
         <!-- <ul>
            <li class="facebook">
              <a href="#">
                <span class="fa fa-facebook"></span>
              </a>
            </li>
            <li class="twitter">
              <a href="#">
                <span class="fa fa-twitter"></span>
              </a>
            </li>
            <li class="rss">
              <a href="#">
                <span class="fa fa-rss"></span>
              </a>
            </li>
          </ul> -->
        </div>
        <div class="banner-right-txt">
          <h5 class="mb-sm-3 mb-2">"Be sweet as a mango"</h5>
          <h4>MID DAY MEALS</h4>
        </div>
        <div class="slide-info-txt">
        <!--  <p>Lorem ipsum dolor sit amet consectetur adipiscing elit, sed do eiusmod tempor incididunt utadipiscing elit sed
            do eiusmod tempor incididunt Lorem</p> -->
        </div>
      </div>
    </div>
  </div>
  <!-- //banner -->
  <!-- about -->
  <section class="about py-lg-4 py-md-4 py-sm-3 py-3" id="about">
    <div class="container py-lg-5 py-md-4 py-sm-4 py-3">
      <h3 class="title text-center mb-2">About Us</h3>
      <div class="title-w3ls-text text-center mb-lg-5 mb-md-4 mb-sm-4 mb-3">
     <!--   <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et Lorem ipsum
        </p> -->
      </div>
      <div class="row">
        <div class="col-lg-5 video-info-img text-center position-relative">
          <div class="abut-img-w3l">
            <img src="../midday_meals/images/02.jpg" alt="" class="img-fluid">
          </div>
          <div class="abut-img-two">
            <img src="../midday_meals/images/03.jpg" alt="" class="img-fluid">
          </div>
        </div>
        <div class="col-lg-7 left-abut-txt ">
          <div class="about-right-grid">
            <h2 class="mb-3">Abstract </h2>
            <p>The Midday Meal Scheme is a school meal programme in India designed to better the nutritional standing of school-age children nationwide.[1] The programme supplies free lunches on working days for children in primary and upper primary classes in government, government aided, local body, Education Guarantee Scheme, and alternate innovative education centres, Madarsa and Maqtabs supported under Sarva Shiksha Abhiyan, and National Child Labour Project schools run by the ministry of labour.[2] Serving 120 million children in over 1.27 million schools and Education Guarantee Scheme centres, the Midday Meal Scheme is the largest of its kind in the world.</p>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!--//about -->
  <!-- store-info -->
  <section class="store-info py-lg-4 py-md-4 py-sm-3 py-3">
    <div class="container py-lg-5 py-md-4 py-sm-4 py-3">
      <div class="row">
        

      </div>
    </div>
  </section>
  <!--//store-info -->
  <!-- service -->
  <section class="service py-lg-4 py-md-4 py-sm-3 py-3" id="service">
    <div class="container py-lg-5 py-md-4 py-sm-4 py-3">
      <h3 class="title text-center mb-2">Services</h3>
      <div class="title-w3ls-text text-center mb-lg-5 mb-md-4 mb-sm-4 mb-3">
        <p>Objectives of the project:
        </p>
      </div>
      <div class="row">
        <div class="col-lg-4 col-md-6 col-sm-6 ser-icon text-center my-3">
          <div class="grid-wthree-service">
            <img src="images/g4.jpg" alt="news image" class="img-fluid">
            <div class="ser-text-wthree mt-3">
              <h4>
                
              </h4>
              <p class="mt-2">Healthier you will feel if you eat a healthy meal.</p>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 col-sm-6 ser-icon text-center my-3">
          <div class="grid-wthree-service">
            <img src="images/g3.jpg" alt="news image" class="img-fluid">
            <div class="ser-text-wthree mt-3">
              <h4>
               <!-- Fresh Fruits -->
              </h4>
              <p class="mt-2">Know the actual deal about your meal!</p>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 col-sm-6 ser-icon text-center my-3">
          <div class="grid-wthree-service">
            <img src="images/g2.jpg" alt="news image" class="img-fluid">
            <div class="ser-text-wthree mt-3">
              <h4>
                <!--Garden Tillage -->
              </h4>
              <p class="mt-2">	Full of energy you will feel, after eating a vigorous meal</p>
            </div>
          </div>
        </div>
        
        
      </div>
    </div>
  </section>
  <!--//service -->
  <!-- vegetable-info -->
  <section class="veg-info py-lg-4 py-md-4 py-sm-3 py-3">
    <div class="container py-lg-5 py-md-4 py-sm-4 py-3">
      
      
    </div>
  </section>
  <!--//vegetable-info -->
  <!-- gallery -->
  <section class="gallery py-lg-4 py-md-3 py-sm-3 py-3" id="gallery">
    <div class="container py-lg-5 py-md-4 py-sm-4 py-3">
      <h3 class="title text-center mb-2">Gallery </h3>
      <div class="title-w3ls-text text-center mb-lg-5 mb-md-4 mb-sm-4 mb-3">
        <p>Mid-day meal (MDM) is a wholesome freshly-cooked lunch served to children in government and government-aided schools in India.

        </p>
      </div>
      <div class="row gallery-info">
        <div class="col-lg-4 col-md-6 col-sm-6 gallery-img-grid my-3">
          <div class="gallery-grids">
            <a href="#gal1">
              <img src="../midday_meals/images/g1.jpg" alt="news image" class="img-fluid">
            </a>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 col-sm-6 gallery-img-grid my-3">
          <div class="gallery-grids">
            <a href="#gal2">
              <img src="../midday_meals/images/bb2.jpg" alt="news image" class="img-fluid">
            </a>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 col-sm-6 gallery-img-grid my-3">
          <div class="gallery-grids">
            <a href="#gal3">
              <img src="../midday_meals/images/bb3.jpg" alt="news image" class="img-fluid">
            </a>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 col-sm-6 gallery-img-grid my-3">
          <div class="gallery-grids">
            <a href="#gal4">
              <img src="../midday_meals/images/g2.jpg" alt="news image" class="img-fluid">
            </a>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 col-sm-6 gallery-img-grid my-3">
          <div class="gallery-grids">
            <a href="#gal5">
              <img src="../midday_meals/images/g3.jpg" alt="news image" class="img-fluid">
            </a>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 col-sm-6 gallery-img-grid my-3">
          <div class="gallery-grids">
            <a href="#gal6">
              <img src="../midday_meals/images/g4.jpg" alt="news image" class="img-fluid">
            </a>
          </div>
        </div>
      </div>
      <!-- popup-->
      <div id="gal1" class="popup-effect">
        <div class="popup">
          <img src="../midday_meals/images/g1.jpg" alt="Popup Image" class="img-fluid">
          <a class="close" href="#gallery">×</a>
        </div>
      </div>
      <!-- //popup -->
      <!-- popup-->
      <div id="gal2" class="popup-effect">
        <div class="popup">
          <img src="../midday_meals/images/bb2.jpg" alt="Popup Image" class="img-fluid">
          <a class="close" href="#gallery">×</a>
        </div>
      </div>
      <!-- //popup -->
      <!-- popup-->
      <div id="gal3" class="popup-effect">
        <div class="popup">
          <img src="../midday_meals/images/bb3.jpg" alt="Popup Image" class="img-fluid">
          <a class="close" href="#gallery">×</a>
        </div>
      </div>
      <!-- //popup -->
      <!-- popup-->
      <div id="gal4" class="popup-effect">
        <div class="popup">
          <img src="../midday_meals/images/g2.jpg" alt="Popup Image" class="img-fluid">
          <a class="close" href="#gallery">×</a>
        </div>
      </div>
      <!-- //popup -->
      <!-- popup-->
      <div id="gal5" class="popup-effect">
        <div class="popup">
          <img src="../midday_meals/images/g3.jpg" alt="Popup Image" class="img-fluid">
          <a class="close" href="#gallery">×</a>
        </div>
      </div>
      <!-- //popup -->
      <!-- popup-->
      <div id="gal6" class="popup-effect">
        <div class="popup">
          <img src="../midday_meals/images/g4.jpg" alt="Popup Image" class="img-fluid">
          <a class="close" href="#gallery">×</a>
        </div>
      </div>
      <!-- //popup -->
    </div>
  </section>
  <!--//gallery -->
  
  
  <!--footer-copy-right -->
  <footer class="bottem-wthree-footer text-center py-md-4 py-3">
    <p>
      © 2022 All Rights Reserved by Mid Day Meals  | Designed and Developed by BCA Students.
    </p>
  </footer>
  <!--//footer-copy-right -->

</body>

</html>